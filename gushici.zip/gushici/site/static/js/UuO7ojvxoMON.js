(this.webpackJsonphzzm = this.webpackJsonphzzm || []).push([
  [0],
  {
    36: function (t, e, a) {
      t.exports = a(77);
    },
    42: function (t, e, a) {},
    43: function (t, e, a) {},
    44: function (t, e, a) {},
    62: function (t, e, a) {},
    63: function (t, e, a) {},
    64: function (t, e, a) {},
    65: function (t, e, a) {},
    66: function (t, e, a) {},
    72: function (t, e, a) {},
    76: function (t, e, a) {},
    77: function (t, e, a) {
      "use strict";
      a.r(e);
      var n = a(0),
        c = a.n(n),
        r = a(11),
        i = a.n(r),
        o = (a(41), a(42), a(15)),
        s = a(5),
        l = (a(43), a(1)),
        u = a(2),
        h = a(4),
        m = a(3);
      a(44);
      var p,
        v = function (t) {
          var e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : "1.2em",
            a =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : "1.2em";
          return c.a.createElement(
            "svg",
            { viewBox: "0 0 24 24", width: e, height: a, fill: "currentColor" },
            c.a.createElement("path", { d: t })
          );
        };
      a(34).a.newInstance({ prefixCls: "notice", style: {} }, function (t) {
        return (p = t);
      });
      var d = function (t, e, a) {
          p.notice({
            content: c.a.createElement(
              "div",
              { className: "notice-content", style: { background: a } },
              t,
              " ",
              c.a.createElement("span", { className: "notice-tip" }, e)
            ),
          });
        },
        f = function (t) {
          return d(
            v(
              "M11 15h2v2h-2zm0-8h2v6h-2zm.99-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
            ),
            t,
            "#f44336"
          );
        },
        g = function (t) {
          return d(
            v(
              "M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2, 4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0, 0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"
            ),
            t,
            "#4caf50"
          );
        },
        y = a(31),
        E = a.n(y),
        k = a(17),
        b = a.n(k);
      var j = a(14),
        O = E.a.create({
          baseURL: "https://hzzm.xusenlin.com/v1",
          headers: { Accept: "*/*" },
          timeout: 1e4,
        });
      (O.defaults.retry = 4),
        (O.defaults.retryDelay = 800),
        O.interceptors.request.use(
          function (t) {
            return (
              t.closeLoading || b.a.start(),
              (t.headers.Authorization = j.a.get("HZZM_ACCESS_TOKEN") || ""),
              t
            );
          },
          function (t) {
            Promise.reject(t);
          }
        ),
        O.interceptors.response.use(
          function (t) {
            return (
              setTimeout(function () {
                b.a.done();
              }, 100),
              200 !== t.status
                ? (f("Status Code Is Not 200"), Promise.reject(t))
                : !0 !== t.data.status
                ? ((function (t) {
                    d(
                      v(
                        "M12 5.99L19.53 19H4.47L12 5.99M12 2L1 21h22L12 2zm1 14h-2v2h2v-2zm0-6h-2v4h2v-4z"
                      ),
                      t,
                      "#ff9800"
                    );
                  })(t.data.msg),
                  Promise.reject(t))
                : t.data.data
            );
          },
          function (t) {
            return f(t.message), b.a.done(), Promise.reject(t);
          }
        );
      var C = O;
      a(62);
      var L = (function (t) {
        Object(h.a)(a, t);
        var e = Object(m.a)(a);
        function a(t) {
          var n;
          return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
        }
        return (
          Object(u.a)(a, [
            {
              key: "render",
              value: function () {
                var t = this;
                return c.a.createElement(
                  "div",
                  { className: "search-btn" },
                  (function () {
                    for (
                      var t = arguments.length, e = new Array(t), a = 0;
                      a < t;
                      a++
                    )
                      e[a] = arguments[a];
                    return v.apply(
                      void 0,
                      [
                        "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z",
                      ].concat(e)
                    );
                  })("30px", "30px"),
                  c.a.createElement(
                    "div",
                    { className: "search-input" },
                    c.a.createElement("input", {
                      type: "text",
                      placeholder: "请完整输入标题或作者后回车",
                      onKeyDown: function (e) {
                        13 === (window.event || e).keyCode &&
                          t.props.ok(e.target.value);
                      },
                    })
                  )
                );
              },
            },
          ]),
          a
        );
      })(c.a.Component);
      a(63), a(64);
      var N = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return (
              Object(l.a)(this, a),
              ((n = e.call(this, t)).state = {
                open: !1,
                content: "",
                title: "",
              }),
              n
            );
          }
          return (
            Object(u.a)(a, [
              {
                key: "openPopup",
                value: function (t, e) {
                  this.setState({ open: !0, title: t, content: e });
                },
              },
              {
                key: "closePopup",
                value: function () {
                  this.setState({ open: !1 });
                },
              },
              {
                key: "render",
                value: function () {
                  var t = this;
                  return (
                    this.state.open &&
                    c.a.createElement(
                      "div",
                      { className: "mask" },
                      c.a.createElement(
                        "div",
                        { className: "popup" },
                        c.a.createElement(
                          "div",
                          { className: "title" },
                          this.state.title
                        ),
                        c.a.createElement(
                          "div",
                          { className: "content" },
                          this.state.content
                        ),
                        c.a.createElement(
                          "div",
                          { className: "btn-group" },
                          c.a.createElement(
                            "div",
                            {
                              className: "btn",
                              onClick: function () {
                                t.closePopup();
                              },
                            },
                            "关闭"
                          )
                        )
                      )
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        w = document.getElementById("popup"),
        S = i.a.render(c.a.createElement(N, null), w),
        z =
          (a(65),
          (function (t) {
            Object(h.a)(a, t);
            var e = Object(m.a)(a);
            function a(t) {
              var n;
              return (
                Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n
              );
            }
            return (
              Object(u.a)(a, [
                {
                  key: "render",
                  value: function () {
                    return c.a.createElement(
                      "div",
                      { className: "star-btn", onClick: this.props.clickBtn },
                      this.props.children
                    );
                  },
                },
              ]),
              a
            );
          })(c.a.Component)),
        x = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "seekAuthor",
                value: function (t) {
                  var e;
                  ((e = { name: t }),
                  C({ url: "/author", method: "get", params: e }))
                    .then(function (e) {
                      !(function () {
                        S.openPopup.apply(S, arguments);
                      })(t + "  •  " + e.dynasty, e.desc);
                    })
                    .catch(function () {});
                },
              },
              {
                key: "render",
                value: function () {
                  var t = this;
                  return c.a.createElement(
                    "div",
                    { className: "warp" },
                    c.a.createElement("h1", null, this.props.title),
                    c.a.createElement(
                      "ul",
                      { className: "poetry" },
                      this.props.list.map(function (e, a) {
                        return c.a.createElement(
                          "li",
                          { className: "node", key: e.id },
                          c.a.createElement(
                            "p",
                            { className: "title" },
                            e.title
                          ),
                          c.a.createElement(
                            "p",
                            {
                              className: "author",
                              onClick: function () {
                                t.seekAuthor(e.author);
                              },
                            },
                            e.author
                          ),
                          c.a.createElement(
                            "div",
                            { className: "paragraphs" },
                            e.paragraphs.split("||").map(function (t, e) {
                              return c.a.createElement(
                                "div",
                                { className: "paragraph", key: e },
                                t
                              );
                            })
                          ),
                          c.a.createElement(
                            z,
                            {
                              clickBtn: function () {
                                t.props.favour && t.props.favour(e.id, a);
                              },
                            },
                            "点赞(",
                            e.star,
                            ")"
                          )
                        );
                      })
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        P = a(35),
        M = (a(66), a(32)),
        A = a.n(M),
        _ = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "render",
                value: function () {
                  var t = this.props,
                    e = t.change,
                    a = Object(P.a)(t, ["change"]);
                  return c.a.createElement(
                    A.a,
                    Object.assign(
                      {
                        containerClassName: "paginate",
                        previousLabel: "上一页",
                        nextLabel: "下一页",
                        onPageChange: function (t) {
                          e(t.selected + 1);
                        },
                        disabledClassName: "disabled",
                      },
                      a
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        F = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return (
              Object(l.a)(this, a),
              ((n = e.call(this, t)).state = {
                keyword: "",
                data: { list: [] },
              }),
              n
            );
          }
          return (
            Object(u.a)(a, [
              {
                key: "componentDidMount",
                value: function () {
                  this.getList();
                },
              },
              {
                key: "searchResult",
                value: function (t) {
                  var e = this;
                  this.setState({ keyword: t }, function () {
                    e.getList();
                  });
                },
              },
              {
                key: "getList",
                value: function () {
                  var t = this;
                  (function (t) {
                    return C({ url: "/ts", method: "get", params: t });
                  })({
                    pageNum:
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : 1,
                    keyword: this.state.keyword,
                  })
                    .then(function (e) {
                      t.setState({ data: e });
                    })
                    .catch(function () {});
                },
              },
              {
                key: "clickFavour",
                value: function (t, e) {
                  var a,
                    n = this,
                    c = this.state.data;
                  (c.list[e].star = ++c.list[e].star),
                    ((a = { id: t }),
                    C({
                      closeLoading: !0,
                      url: "/ts/favour",
                      method: "get",
                      params: a,
                    }))
                      .then(function () {
                        n.setState({ data: c }), g("点赞成功");
                      })
                      .catch(function () {});
                },
              },
              {
                key: "render",
                value: function () {
                  var t = this;
                  return c.a.createElement(
                    "div",
                    null,
                    c.a.createElement(x, {
                      title: "唐诗",
                      list: this.state.data.list,
                      favour: function (e, a) {
                        t.clickFavour(e, a);
                      },
                    }),
                    c.a.createElement(_, {
                      pageCount: this.state.data.totalPage,
                      change: function (e) {
                        t.getList(e);
                      },
                    }),
                    c.a.createElement(L, {
                      ok: function (e) {
                        t.searchResult(e);
                      },
                    })
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component);
      var R = (function (t) {
        Object(h.a)(a, t);
        var e = Object(m.a)(a);
        function a(t) {
          var n;
          return (
            Object(l.a)(this, a),
            ((n = e.call(this, t)).state = { keyword: "", data: { list: [] } }),
            n
          );
        }
        return (
          Object(u.a)(a, [
            {
              key: "componentDidMount",
              value: function () {
                this.getList();
              },
            },
            {
              key: "getList",
              value: function () {
                var t = this;
                (function (t) {
                  return C({ url: "/ss", method: "get", params: t });
                })({
                  pageNum:
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 1,
                  keyword: this.state.keyword,
                })
                  .then(function (e) {
                    t.setState({ data: e });
                  })
                  .catch(function () {});
              },
            },
            {
              key: "searchResult",
              value: function (t) {
                var e = this;
                this.setState({ keyword: t }, function () {
                  e.getList();
                });
              },
            },
            {
              key: "clickFavour",
              value: function (t, e) {
                var a,
                  n = this,
                  c = this.state.data;
                (c.list[e].star = ++c.list[e].star),
                  ((a = { id: t }),
                  C({
                    closeLoading: !0,
                    url: "/ss/favour",
                    method: "get",
                    params: a,
                  }))
                    .then(function () {
                      n.setState({ data: c }), g("点赞成功");
                    })
                    .catch(function () {});
              },
            },
            {
              key: "render",
              value: function () {
                var t = this;
                return c.a.createElement(
                  "div",
                  null,
                  c.a.createElement(x, {
                    title: "宋诗",
                    list: this.state.data.list,
                    favour: function (e, a) {
                      t.clickFavour(e, a);
                    },
                  }),
                  c.a.createElement(_, {
                    pageCount: this.state.data.totalPage,
                    change: function (e) {
                      t.getList(e);
                    },
                  }),
                  c.a.createElement(L, {
                    ok: function (e) {
                      t.searchResult(e);
                    },
                  })
                );
              },
            },
          ]),
          a
        );
      })(c.a.Component);
      var D = (function (t) {
        Object(h.a)(a, t);
        var e = Object(m.a)(a);
        function a(t) {
          var n;
          return (
            Object(l.a)(this, a),
            ((n = e.call(this, t)).state = { keyword: "", data: { list: [] } }),
            n
          );
        }
        return (
          Object(u.a)(a, [
            {
              key: "componentDidMount",
              value: function () {
                this.getList();
              },
            },
            {
              key: "getList",
              value: function () {
                var t = this;
                (function (t) {
                  return C({ url: "/sc", method: "get", params: t });
                })({
                  pageNum:
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 1,
                  keyword: this.state.keyword,
                })
                  .then(function (e) {
                    t.setState({ data: e });
                  })
                  .catch(function () {});
              },
            },
            {
              key: "searchResult",
              value: function (t) {
                var e = this;
                this.setState({ keyword: t }, function () {
                  e.getList();
                });
              },
            },
            {
              key: "clickFavour",
              value: function (t, e) {
                var a,
                  n = this,
                  c = this.state.data;
                (c.list[e].star = ++c.list[e].star),
                  ((a = { id: t }),
                  C({
                    closeLoading: !0,
                    url: "/sc/favour",
                    method: "get",
                    params: a,
                  }))
                    .then(function () {
                      n.setState({ data: c }), g("点赞成功");
                    })
                    .catch(function () {});
              },
            },
            {
              key: "render",
              value: function () {
                var t = this;
                return c.a.createElement(
                  "div",
                  null,
                  c.a.createElement(x, {
                    title: "宋词",
                    list: this.state.data.list,
                    favour: function (e, a) {
                      t.clickFavour(e, a);
                    },
                  }),
                  c.a.createElement(_, {
                    pageCount: this.state.data.totalPage,
                    change: function (e) {
                      t.getList(e);
                    },
                  }),
                  c.a.createElement(L, {
                    ok: function (e) {
                      t.searchResult(e);
                    },
                  })
                );
              },
            },
          ]),
          a
        );
      })(c.a.Component);
      var B = (function (t) {
        Object(h.a)(a, t);
        var e = Object(m.a)(a);
        function a(t) {
          var n;
          return (
            Object(l.a)(this, a),
            ((n = e.call(this, t)).state = { keyword: "", data: { list: [] } }),
            n
          );
        }
        return (
          Object(u.a)(a, [
            {
              key: "componentDidMount",
              value: function () {
                this.getList();
              },
            },
            {
              key: "getList",
              value: function () {
                var t = this;
                (function (t) {
                  return C({ url: "/yq", method: "get", params: t });
                })({
                  pageNum:
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : 1,
                  keyword: this.state.keyword,
                })
                  .then(function (e) {
                    t.setState({ data: e });
                  })
                  .catch(function () {});
              },
            },
            {
              key: "searchResult",
              value: function (t) {
                var e = this;
                this.setState({ keyword: t }, function () {
                  e.getList();
                });
              },
            },
            {
              key: "clickFavour",
              value: function (t, e) {
                var a,
                  n = this,
                  c = this.state.data;
                (c.list[e].star = ++c.list[e].star),
                  ((a = { id: t }),
                  C({
                    closeLoading: !0,
                    url: "/yq/favour",
                    method: "get",
                    params: a,
                  }))
                    .then(function () {
                      n.setState({ data: c }), g("点赞成功");
                    })
                    .catch(function () {});
              },
            },
            {
              key: "render",
              value: function () {
                var t = this;
                return c.a.createElement(
                  "div",
                  null,
                  c.a.createElement(x, {
                    title: "元曲",
                    list: this.state.data.list,
                    favour: function (e, a) {
                      t.clickFavour(e, a);
                    },
                  }),
                  c.a.createElement(_, {
                    pageCount: this.state.data.totalPage,
                    change: function (e) {
                      t.getList(e);
                    },
                  }),
                  c.a.createElement(L, {
                    ok: function (e) {
                      t.searchResult(e);
                    },
                  })
                );
              },
            },
          ]),
          a
        );
      })(c.a.Component);
      a(72);
      var I = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "render",
                value: function () {
                  return c.a.createElement(
                    "div",
                    { className: "warp" },
                    c.a.createElement("h1", null, this.props.title),
                    c.a.createElement(
                      "ul",
                      { className: "chapters" },
                      this.props.list.map(function (t) {
                        return c.a.createElement(
                          "li",
                          { className: "node", key: t.id },
                          c.a.createElement(
                            "p",
                            { className: "chapter" },
                            t.chapter
                          ),
                          c.a.createElement(
                            "div",
                            { className: "paragraphs" },
                            t.paragraphs.split("||").map(function (t, e) {
                              return c.a.createElement(
                                "div",
                                { className: "paragraph", key: e },
                                t
                              );
                            })
                          )
                        );
                      })
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        H = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return (
              Object(l.a)(this, a),
              ((n = e.call(this, t)).state = { data: { list: [] } }),
              n
            );
          }
          return (
            Object(u.a)(a, [
              {
                key: "componentDidMount",
                value: function () {
                  this.getList();
                },
              },
              {
                key: "getList",
                value: function () {
                  var t = this;
                  (function (t) {
                    return C({ url: "/ly", method: "get", params: t });
                  })({
                    pageNum:
                      arguments.length > 0 && void 0 !== arguments[0]
                        ? arguments[0]
                        : 1,
                    pageSize: 1,
                  })
                    .then(function (e) {
                      t.setState({ data: e });
                    })
                    .catch(function () {});
                },
              },
              {
                key: "render",
                value: function () {
                  var t = this;
                  return c.a.createElement(
                    "div",
                    null,
                    c.a.createElement(I, {
                      title: "论语",
                      list: this.state.data.list,
                    }),
                    c.a.createElement(_, {
                      pageCount: this.state.data.totalPage,
                      change: function (e) {
                        t.getList(e);
                      },
                    })
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component);
      var T = [
          { title: "唐诗", path: "/tang_si", component: F },
          { title: "宋诗", path: "/song_shi", component: R },
          { title: "宋词", path: "/song_ci", component: D },
          { title: "元曲", path: "/yuan_qu", component: B },
          {
            title: "四书五经",
            path: "/si_shu_wu_jing",
            component: (function (t) {
              Object(h.a)(a, t);
              var e = Object(m.a)(a);
              function a(t) {
                var n;
                return (
                  Object(l.a)(this, a),
                  ((n = e.call(this, t)).state = { data: { list: [] } }),
                  n
                );
              }
              return (
                Object(u.a)(a, [
                  {
                    key: "componentDidMount",
                    value: function () {
                      this.getList();
                    },
                  },
                  {
                    key: "getList",
                    value: function () {
                      var t = this;
                      (function (t) {
                        return C({ url: "/sswj", method: "get", params: t });
                      })({
                        pageNum:
                          arguments.length > 0 && void 0 !== arguments[0]
                            ? arguments[0]
                            : 1,
                        pageSize: 1,
                      })
                        .then(function (e) {
                          t.setState({ data: e });
                        })
                        .catch(function () {});
                    },
                  },
                  {
                    key: "render",
                    value: function () {
                      var t = this;
                      return c.a.createElement(
                        "div",
                        null,
                        c.a.createElement(I, {
                          title: "四书五经",
                          list: this.state.data.list,
                        }),
                        c.a.createElement(_, {
                          pageCount: this.state.data.totalPage,
                          change: function (e) {
                            t.getList(e);
                          },
                        })
                      );
                    },
                  },
                ]),
                a
              );
            })(c.a.Component),
          },
          { title: "论语", path: "/lun_yu", component: H },
          {
            title: "关于",
            path: "/about",
            component: function () {
              return c.a.createElement(
                "div",
                { style: { marginTop: 48 } },
                c.a.createElement("h1", null, "关于"),
                c.a.createElement(
                  "div",
                  {
                    style: {
                      padding: "20px",
                      textAlign: "left",
                      margin: "0 auto",
                      maxWidth: "500px",
                      minHeight: "calc(100vh - 178px)",
                    },
                  },
                  c.a.createElement(
                    "p",
                    null,
                    "这是一个公益网站，没用任何广告，PC和移动端都有着良好的阅读体验。"
                  ),
                  c.a.createElement(
                    "p",
                    null,
                    "并且会随着数据仓库的更新而更新，目前数据的统计如下："
                  ),
                  c.a.createElement(
                    "p",
                    null,
                    "唐诗57612首，宋诗254248首，宋词21053首，元曲11057首"
                  ),
                  c.a.createElement(
                    "p",
                    null,
                    "当然还有更多的数据，我有时间的话会看情况添加进来"
                  ),
                  c.a.createElement(
                    "p",
                    null,
                    "如果你也喜欢这个网站，不妨给我发送邮件，一个小小的建议或者更好的想法都欢迎和我交流。"
                  ),
                  c.a.createElement("p", null, "邮箱：locusli1987@outlook.com")
                )
              );
            },
          },
        ],
        q = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "render",
                value: function () {
                  return c.a.createElement(
                    "div",
                    { className: "container head" },
                    c.a.createElement("div", { className: "logo" }, "诗词文赋"),
                    c.a.createElement(
                      "div",
                      { className: "nav" },
                      T.map(function (t) {
                        return c.a.createElement(
                          o.b,
                          { key: t.path, to: t.path },
                          t.title
                        );
                      })
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        W = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "render",
                value: function () {
                  return c.a.createElement(
                    "div",
                    { className: "container foot" },
                    "© 2023",
                    c.a.createElement(
                      "a",
                      { href: "/#" },
                      "诗词文赋"
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        Z =
          (a(76),
          [
            "#673ab7",
            "#f44336",
            "#9c27b0",
            "#2196f3",
            "#607d8b",
            "#795548",
            "#8bc34a",
          ]),
        J = (function (t) {
          Object(h.a)(a, t);
          var e = Object(m.a)(a);
          function a(t) {
            var n;
            return Object(l.a)(this, a), ((n = e.call(this, t)).state = {}), n;
          }
          return (
            Object(u.a)(a, [
              {
                key: "render",
                value: function () {
                  return c.a.createElement(
                    "div",
                    { className: "theme-btn" },
                    (function () {
                      for (
                        var t = arguments.length, e = new Array(t), a = 0;
                        a < t;
                        a++
                      )
                        e[a] = arguments[a];
                      return v.apply(
                        void 0,
                        [
                          "M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9c.83 0 1.5-.67 1.5-1.5 0-.39-.15-.74-.39-1.01-.23-.26-.38-.61-.38-.99 0-.83.67-1.5 1.5-1.5H16c2.76 0 5-2.24 5-5 0-4.42-4.03-8-9-8zm-5.5 9c-.83 0-1.5-.67-1.5-1.5S5.67 9 6.5 9 8 9.67 8 10.5 7.33 12 6.5 12zm3-4C8.67 8 8 7.33 8 6.5S8.67 5 9.5 5s1.5.67 1.5 1.5S10.33 8 9.5 8zm5 0c-.83 0-1.5-.67-1.5-1.5S13.67 5 14.5 5s1.5.67 1.5 1.5S15.33 8 14.5 8zm3 4c-.83 0-1.5-.67-1.5-1.5S16.67 9 17.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z",
                        ].concat(e)
                      );
                    })("30px", "30px"),
                    c.a.createElement(
                      "div",
                      { className: "theme-color" },
                      Z.map(function (t) {
                        return c.a.createElement("i", {
                          key: t,
                          onClick: function () {
                            document.documentElement.style.setProperty(
                              "--themeColor",
                              t
                            ),
                              localStorage.setItem("THEME", t);
                          },
                          className: "color",
                          style: { background: t },
                        });
                      })
                    )
                  );
                },
              },
            ]),
            a
          );
        })(c.a.Component),
        K = Object(s.g)(function (t) {
          return c.a.createElement(
            "div",
            null,
            c.a.createElement(q, null),
            c.a.createElement(
              "div",
              { className: "container content" },
              c.a.createElement(
                s.d,
                null,
                T.map(function (t) {
                  return c.a.createElement(s.b, {
                    exact: !0,
                    key: t.path,
                    path: t.path,
                    component: t.component,
                  });
                }),
                c.a.createElement(s.a, { to: "/tang_si" })
              )
            ),
            c.a.createElement(J, null),
            c.a.createElement(W, null)
          );
        }),
        U = {
          notFound: {
            width: "100%",
            height: "100vh",
            fontSize: "80px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          },
        },
        $ = function () {
          return c.a.createElement("div", { style: U.notFound }, "4 0 4");
        };
      Boolean(
        "localhost" === window.location.hostname ||
          "[::1]" === window.location.hostname ||
          window.location.hostname.match(
            /^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/
          )
      ),
        i.a.render(
          c.a.createElement(function () {
            return c.a.createElement(
              "div",
              null,
              c.a.createElement(
                o.a,
                null,
                c.a.createElement(
                  s.d,
                  null,
                  c.a.createElement(s.b, {
                    exact: !0,
                    path: "/404",
                    component: $,
                  }),
                  c.a.createElement(K, { path: "/", component: K })
                )
              )
            );
          }, null),
          document.getElementById("root")
        ),
        "serviceWorker" in navigator &&
          navigator.serviceWorker.ready.then(function (t) {
            t.unregister();
          });
      var G = localStorage.getItem("THEME");
      G &&
        7 === G.length &&
        document.documentElement.style.setProperty("--themeColor", G);
    },
  },
  [[36, 1, 2]],
]);
